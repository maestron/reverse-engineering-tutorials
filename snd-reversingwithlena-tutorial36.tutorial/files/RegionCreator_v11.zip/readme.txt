                ____________________________________________________
               /    ______                 __    __                /|
       	      /    / ____/                / /   /_/               / |
             /    / /_____  _____________/ /________________     / /
            /    / __  / / / / __  /  __/ __  / / __  / ___/    / /
           /     ___/ / /_/ / / / /__  / / / / / / / / ___/    / /
          /    /_____/_____/_/ /_/____/_/ /_/_/_/ /_/____/    / /
         /                                                   / /
        /     Web : www.sunhine2k.de                        / /    					
       /      Mail: info@sunhine2k.de                      / /
      /___________________________________________________/ /
      \____________________________________________________/


Region Creator 1.1:
------------------------------
This little application scans an image for a chosen transparent color and save this region to file.


Features:
---------
* supports bmp, png, gif and jpeg files
* choose transparent color from image or type in the RGB values
* preview of region
* Save region as a rgn file or as a C source file



New in Version 1.1:
-------------------
* Option to save the region to a C source file. So you don't have to include a rgn file to your resource
  or as a file anymore. Just include the generated header file to your project and call one single function
  on startup. That's it :-)
* Possibility to use another layout by specifying the argument -newGUI on the RegionCreator commandline. 
  Well that's not a real feature but I was playing around how to subclass a window and that's the result.
* Some little bugfixes and 'beauty changes'
* More errorhandling



What to do with the saved rgn file?
-----------------------------------
Part 1 : Rgn File
=================
  In the subdirectory 'RgnFileTest' you find an example how to use the rgn file in your application.

  The CSunRegion class makes it easy to use:
  1. create an instance of this class, you have just to supply your window handle:
	for example: CSunRegion* region = new CSunRegion(hwnd);
  
  2a) to load your rgn file and assign it to your window, use the LoadFromFile function:
        for example: region->LoadFromFile("myregion.rgn");
  
  2b) if you have included your rgn file as a resource, use the LoadFromRes function:
        for example: region->LoadFromRes(MAKEINTRESOURCE(IDR_CUSTOM1), "CUSTOM");

  3. after you have called one of these two Load functions, you can immediately delete your class instance if you want.
        for example: delete region;

Part 2 : Source file
====================
  In the subdirectory 'SourceTest'you find an example how to use the source file in your application.

  Just copy the generated header & source file to your project directory and include them, eg:
  #include "filename.h"

  After the window you want the region apply to was created, call the function CreateRgnWindow:
  Syntax of function : bool CreateRgnWindow(HWND hwnd, BOOL bTitlebar, BOOL bResize);
  where
	hwnd : handle to the window
	bTitlebar : true means the titlebar is shown as normal; false means that the titlebar will not be shown.
	bResize : true means that the window will be resized to the dimension of the region. So when you give
		  false here, you're responsible that your window is big enough for the region.



Known bugs/limitations:
-----------------------
* the imagebox is sometimes not drawn correctly, especially the scrollbars. (but there are there!)
* scanning large images can take much time
* saving the regiob as a source file is just acceptable for really small regions! Use better rgn files!



Thanks to :
-----------
* James Brown for his fantastic tutorials for Win32 and System Coding. Visit his site: www.catch22.net
* Michael Chourdakis for his article @ codeguru how to load JPG/GIF/BMP files to a HBITMAP object using plain API
  -> http://www.codeguru.com/cpp/g-m/bitmap/article.php/c4935/



Copyright etc. :
----------------
Feel free to use my source or parts of it. But please mention my name and/or my website. Also I would be
happy if you drop me a line when you use something from my stuff so I can see where my source lands :-)


Sunshine, 2005


